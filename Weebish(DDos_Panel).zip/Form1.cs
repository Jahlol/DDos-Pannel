﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DDos_Pannel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string text = user1.Text;

            string text2 = pass1.Text;



            string value = text + ":" + text2;

            string value2 = text + ":" + text2;

            string USER = user1.Text;

            string PASS = pass1.Text;



            if (USER == "" && PASS == "")

            {

                MessageBox.Show("No Login Entered!");

                this.Close();

            }

            if (PASS == "")

            {

                MessageBox.Show("No Password Entered!");

                this.Close();

            }



            if (USER == "")

            {

                MessageBox.Show("No Username Entered!");

                this.Close();

            }



            WebClient webClient = new WebClient();



            bool flag3 = webClient.DownloadString("https://pastebin.com/raw/samGqzFe").Contains(value);

            if (flag3)

            {

                this.Hide();

                MessageBox.Show($"Welcome {USER} To Encryption0");

                Form2 penis = new Form2();

                penis.ShowDialog();

                this.Close();

            }

            else

            {



                MessageBox.Show("Incorrect Username Or Password Entered!");



            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }



}
