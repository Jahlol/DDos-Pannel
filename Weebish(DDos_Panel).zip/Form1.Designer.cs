﻿namespace DDos_Pannel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.user1 = new System.Windows.Forms.TextBox();
            this.pass1 = new System.Windows.Forms.TextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // user1
            // 
            this.user1.Location = new System.Drawing.Point(341, 156);
            this.user1.Name = "user1";
            this.user1.Size = new System.Drawing.Size(100, 20);
            this.user1.TabIndex = 0;
            this.user1.Text = "username";
            // 
            // pass1
            // 
            this.pass1.Location = new System.Drawing.Point(341, 230);
            this.pass1.Name = "pass1";
            this.pass1.Size = new System.Drawing.Size(100, 20);
            this.pass1.TabIndex = 1;
            this.pass1.Text = "password";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(240, 283);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(293, 32);
            this.metroButton1.TabIndex = 2;
            this.metroButton1.Text = "Login";
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.pass1);
            this.Controls.Add(this.user1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox user1;
        private System.Windows.Forms.TextBox pass1;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}

